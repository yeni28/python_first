string1 = '미세먼지'
string2 = '57'
number1 = 57

print(type(string2)) #type() : 변수의 값이 어떤 종류인지 알려주는 함수
print(type(number1)) #str : String, 문자열 // int: Integer,정수

boolen1 = 300 > 200
boolen2 = 150 == 161

print(boolen1)
print(boolen2)