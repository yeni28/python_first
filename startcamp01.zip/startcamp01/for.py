dusts = [59,24,102]
for value in dusts: #dust라는 리스트를 사용해서 반복, 리스트 안의 값을 value라고 이름짓겠다.
    print(value) #dusts 리스트의 길이 만큼 반복해여 실험, value는 반복이 될때마다 바뀌게 된다.


