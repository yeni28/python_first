#n=0
#while n < 3:
    #print(n)
    #n = n+1 #n의 값을 계쏙 1씩 증가시킨다.#
#print(n) #while의 범위 밖(들여쓰기가 안되어있음)

#n은 0부터 시작
#n이 10보다 작을때까지 반복
#반복할 문장 : n을 출력
#n을 2씩 증가

n=0
while n<10:
    #반복할 문장
    print(n)
    #n을 출력
    n = n+2
    #n을 2씩 증가
print(n)
