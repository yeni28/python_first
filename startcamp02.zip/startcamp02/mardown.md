# 헤딩 (Heading)

## 문서의 제목이나 소제목으로 사용해요

### 글자크기를 키우기 위해서 사용하면 안돼요

#### 4개째

##### 5개째...

###### 끝



1. 리스트 1번
2. 리스트 2번
3. 리스트 3번

* 순서가 없는 리스트 
* 목록을 표시하기 위해서 사용한다.



여기는 코드블록



```python
print('hello')
for i in range(4):
    print("Hello python!!")
    
print('code block')

```



[여기가 링크로 표시될 문자입니다](https://www.naver.com)



![이미지보기](https://cdn.pixabay.com/photo/2016/06/14/00/14/cat-1455468_960_720.jpg)

**집에가고싶다**

*과제안했음*

~~토요일에할거임~~

---

***

___

----

--------

 cheat-sheet

마크다운 가이드.org



# 😊